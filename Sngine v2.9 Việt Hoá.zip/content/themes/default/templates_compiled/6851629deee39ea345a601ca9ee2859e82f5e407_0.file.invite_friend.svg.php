<?php
/* Smarty version 3.1.36, created on 2020-10-12 20:17:24
  from '/home/duyplusn/public_html/content/themes/default/images/svg/invite_friend.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5f84b9d47d33a9_86794761',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6851629deee39ea345a601ca9ee2859e82f5e407' => 
    array (
      0 => '/home/duyplusn/public_html/content/themes/default/images/svg/invite_friend.svg',
      1 => 1602333724,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f84b9d47d33a9_86794761 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
<path style="fill:#FFBA40;" d="M273.588,19.219c-9.88-9.304-25.297-9.304-35.178,0L0,243.712l256,166.862l256-166.862
	L273.588,19.219z"/>
<g>
	<polygon style="fill:#F79E02;" points="23.152,221.911 0,243.712 173.022,356.488 196.343,334.798 	"/>
	<polygon style="fill:#F79E02;" points="338.978,356.488 512,243.712 488.848,221.911 315.657,334.798 	"/>
</g>
<path style="fill:#EAEAF1;" d="M399.011,76.225H112.989c-12.222,0-22.13,9.908-22.13,22.13v322.52H421.14V98.356
	C421.141,86.134,411.233,76.225,399.011,76.225z"/>
<path style="fill:#FD6064;" d="M256,151.92c-84.043-82.135-222.671,48.403-11.116,166.103c6.906,3.843,15.326,3.843,22.232,0
	C478.671,200.322,340.043,69.784,256,151.92z"/>
<path style="fill:#F0484A;" d="M213.279,127.946c-76.625-16.855-146.221,91.143,31.605,190.077c2.301,1.281,4.773,2.125,7.299,2.552
	C126.116,232.042,156.306,141.539,213.279,127.946z"/>
<g>
	<path style="fill:#3A444A;" d="M211.111,234.726c-4.267,0-7.726-3.459-7.726-7.726v-8.124c0-4.267,3.459-7.726,7.726-7.726
		c4.267,0,7.726,3.459,7.726,7.726v8.124C218.837,231.266,215.378,234.726,211.111,234.726z"/>
	<path style="fill:#3A444A;" d="M300.889,234.726c-4.267,0-7.726-3.459-7.726-7.726v-8.124c0-4.267,3.459-7.726,7.726-7.726
		c4.267,0,7.726,3.459,7.726,7.726v8.124C308.615,231.266,305.156,234.726,300.889,234.726z"/>
	<path style="fill:#3A444A;" d="M256,239.063c-6.548,0-12.706-2.75-16.896-7.544c-2.808-3.213-2.48-8.094,0.732-10.902
		c3.211-2.808,8.093-2.481,10.902,0.732c1.256,1.436,3.173,2.26,5.261,2.26c2.088,0,4.006-0.824,5.261-2.26
		c2.807-3.213,7.688-3.541,10.902-0.732c3.213,2.808,3.542,7.689,0.732,10.902C268.706,236.313,262.548,239.063,256,239.063z"/>
</g>
<polygon style="fill:#CCCDD9;" points="256,373.682 90.859,266.043 90.859,420.875 421.141,420.875 421.141,266.043 "/>
<path style="fill:#FFE17C;" d="M446.409,359.457l-80.75-20.361l0,0L256,410.574l-109.66-71.476l-98.611,14.659L0,475.202
	c0,13.562,10.994,24.556,24.556,24.556h462.887c13.562,0,24.556-10.994,24.556-24.556L446.409,359.457z"/>
<g>
	<polygon style="fill:#FFBA40;" points="0,475.202 146.34,339.097 0,243.712 	"/>
	<polygon style="fill:#FFBA40;" points="512,475.202 365.66,339.097 512,243.712 	"/>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
