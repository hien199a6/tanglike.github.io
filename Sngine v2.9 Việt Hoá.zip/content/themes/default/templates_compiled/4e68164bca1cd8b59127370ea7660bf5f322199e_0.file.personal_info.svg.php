<?php
/* Smarty version 3.1.36, created on 2020-10-13 13:56:05
  from '/home/duyplusn/public_html/content/themes/default/images/svg/personal_info.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5f85b1f52218f2_32681475',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4e68164bca1cd8b59127370ea7660bf5f322199e' => 
    array (
      0 => '/home/duyplusn/public_html/content/themes/default/images/svg/personal_info.svg',
      1 => 1602333724,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f85b1f52218f2_32681475 (Smarty_Internal_Template $_smarty_tpl) {
?><svg height="512" viewBox="0 0 512 512" width="512" xmlns="http://www.w3.org/2000/svg"><g id="flat"><path d="m424 184-16 32h-352v272h432v-304z" fill="#fbb540"/><path d="m24 216h64a0 0 0 0 1 0 0v240a32 32 0 0 1 -32 32 32 32 0 0 1 -32-32v-240a0 0 0 0 1 0 0z" fill="#ea9d2d"/><path d="m64 376v110.99a32.188 32.188 0 0 1 -16 0v-110.99a8 8 0 0 1 16 0z" fill="#ea9d2d"/><path d="m120 24h272v336h-272z" fill="#eaeae8"/><path d="m88 64h32v152h-32z" fill="#cbcbcb"/><circle cx="256" cy="128" fill="#8feaff" r="64"/><path d="m296 176v1.97a64.036 64.036 0 0 1 -80 0v-1.97a33.3 33.3 0 0 1 22.77-31.59l1.23-.41h32l1.23.41a33.3 33.3 0 0 1 22.77 31.59z" fill="#fbb540"/><path d="m296 176v1.97a64.036 64.036 0 0 1 -80 0v-1.97a33.3 33.3 0 0 1 22.77-31.59l1.23-.41h32l1.23.41a33.3 33.3 0 0 1 22.77 31.59z" fill="#0bafea"/><path d="m277.69 146.27a24 24 0 0 1 -43.38 0 33.217 33.217 0 0 1 4.46-1.86l1.23-.41h32l1.23.41a33.217 33.217 0 0 1 4.46 1.86z" fill="#0bafea"/><path d="m277.69 146.27a24 24 0 0 1 -43.38 0 33.217 33.217 0 0 1 4.46-1.86l1.23-.41h32l1.23.41a33.217 33.217 0 0 1 4.46 1.86z" fill="#0a9acd"/><g fill="#cbcbcb"><path d="m288 232h-64a8 8 0 0 1 0-16h64a8 8 0 0 1 0 16z"/><path d="m304 264h-96a8 8 0 0 1 0-16h96a8 8 0 0 1 0 16z"/><path d="m344 304h-48a8 8 0 0 1 0-16h48a8 8 0 0 1 0 16z"/><path d="m264 336h-16a8 8 0 0 1 0-16h16a8 8 0 0 1 0 16z"/></g><path d="m64 376v110.99a32.188 32.188 0 0 1 -16 0v-110.99a8 8 0 0 1 16 0z" fill="#d18d28"/><path d="m56 352a8 8 0 0 1 -8-8v-16a8 8 0 0 1 16 0v16a8 8 0 0 1 -8 8z" fill="#d18d28"/><path d="m56 304a8 8 0 0 1 -8-8v-32a8 8 0 0 1 16 0v32a8 8 0 0 1 -8 8z" fill="#d18d28"/><path d="m56 88h32v128h-32z" fill="#a8a8a8"/><path d="m376 408h80v48h-80z" fill="#ea9d2d"/><path d="m168 432h-40a8 8 0 0 1 0-16h40a8 8 0 0 1 0 16z" fill="#ea9d2d"/><path d="m184 464h-56a8 8 0 0 1 0-16h56a8 8 0 0 1 0 16z" fill="#ea9d2d"/><circle cx="256" cy="128" fill="#0bafea" r="24"/></g></svg><?php }
}
