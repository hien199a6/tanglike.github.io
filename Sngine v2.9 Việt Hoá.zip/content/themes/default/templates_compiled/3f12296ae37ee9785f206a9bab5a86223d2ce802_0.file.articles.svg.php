<?php
/* Smarty version 3.1.36, created on 2020-10-12 20:17:24
  from '/home/duyplusn/public_html/content/themes/default/images/svg/articles.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5f84b9d4718198_53480352',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3f12296ae37ee9785f206a9bab5a86223d2ce802' => 
    array (
      0 => '/home/duyplusn/public_html/content/themes/default/images/svg/articles.svg',
      1 => 1602333724,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f84b9d4718198_53480352 (Smarty_Internal_Template $_smarty_tpl) {
?><svg height="512" viewBox="0 0 512 512" width="512" xmlns="http://www.w3.org/2000/svg"><g><path d="m392 48h-24v272l-24 48-24-48v-272h-208v448h280a24.006 24.006 0 0 0 24-24v-400a24.006 24.006 0 0 0 -24-24z" fill="#57a4ff"/><g fill="#004fac"><path d="m392 40h-16a32 32 0 0 0 -64 0h-224a32.042 32.042 0 0 0 -32 32v32h-8a8 8 0 0 0 0 16h8v32h-8a8 8 0 0 0 0 16h8v32h-8a8 8 0 0 0 0 16h8v32h-8a8 8 0 0 0 0 16h8v32h-8a8 8 0 0 0 0 16h8v32h-8a8 8 0 0 0 0 16h8v32h-8a8 8 0 0 0 0 16h8v32h-8a8 8 0 0 0 0 16h8v16a32.042 32.042 0 0 0 32 32h304a32.042 32.042 0 0 0 32-32v-400a32.042 32.042 0 0 0 -32-32zm-64 0a16 16 0 0 1 32 0v24h-32zm0 40h32v216h-32zm0 232h32v6.11l-16 32-16-32zm-224 176h-16a16.021 16.021 0 0 1 -16-16v-16h8a8 8 0 0 0 0-16h-8v-32h8a8 8 0 0 0 0-16h-8v-32h8a8 8 0 0 0 0-16h-8v-32h8a8 8 0 0 0 0-16h-8v-32h8a8 8 0 0 0 0-16h-8v-32h8a8 8 0 0 0 0-16h-8v-32h8a8 8 0 0 0 0-16h-8v-32h8a8 8 0 0 0 0-16h-8v-32a16.021 16.021 0 0 1 16-16h16zm304-16a16.021 16.021 0 0 1 -16 16h-272v-432h192v48h-8v-16a8 8 0 0 0 -16 0v96a8 8 0 0 0 16 0v-64h8v200a8.081 8.081 0 0 0 .84 3.58l24 48a8.009 8.009 0 0 0 14.32 0l24-48a8.081 8.081 0 0 0 .84-3.58v-264h16a16.021 16.021 0 0 1 16 16z"/><path d="m352 456h-88a8 8 0 0 0 0 16h88a8 8 0 0 0 0-16z"/><path d="m384 456h-8a8 8 0 0 0 0 16h8a8 8 0 0 0 0-16z"/><path d="m224 72h-80a8 8 0 0 0 0 16h80a8 8 0 0 0 0-16z"/><path d="m168 96h-24a8 8 0 0 0 0 16h24a8 8 0 0 0 0-16z"/></g></g></svg><?php }
}
