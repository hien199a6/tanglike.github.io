<?php
/* Smarty version 3.1.36, created on 2020-10-13 13:04:05
  from '/home/duyplusn/public_html/content/themes/default/images/svg/social_share.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5f85a5c57e5578_56531884',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1258f24862df892c7a64a4f9058a519bb6b2b60b' => 
    array (
      0 => '/home/duyplusn/public_html/content/themes/default/images/svg/social_share.svg',
      1 => 1602333724,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f85a5c57e5578_56531884 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 53 53" style="enable-background:new 0 0 53 53;" xml:space="preserve">
<rect x="27" y="28" style="fill:#424A60;" width="2" height="18"/>
<rect x="37.5" y="2.893" transform="matrix(0.7071 0.7071 -0.7071 0.7071 20.8223 -23.2696)" style="fill:#424A60;" width="2" height="21.213"/>
<rect x="15" y="21.858" transform="matrix(0.7071 0.7071 -0.7071 0.7071 30.1421 -0.7696)" style="fill:#424A60;" width="2" height="28.284"/>
<rect x="10.722" y="13.5" transform="matrix(0.7071 0.7071 -0.7071 0.7071 15.6716 -8.8345)" style="fill:#424A60;" width="15.556" height="2"/>
<rect x="26.893" y="32.5" transform="matrix(0.7071 0.7071 -0.7071 0.7071 34.6716 -16.7046)" style="fill:#424A60;" width="21.213" height="2"/>
<circle style="fill:#43B05C;" cx="48" cy="5" r="5"/>
<circle style="fill:#7383BF;" cx="28" cy="48" r="5"/>
<circle style="fill:#57D8AB;" cx="5" cy="46" r="5"/>
<circle style="fill:#D75A4A;" cx="12" cy="8" r="3"/>
<circle style="fill:#EBBA16;" cx="44" cy="40" r="3"/>
<circle style="fill:#4B6DAA;" cx="28" cy="24" r="7"/>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
