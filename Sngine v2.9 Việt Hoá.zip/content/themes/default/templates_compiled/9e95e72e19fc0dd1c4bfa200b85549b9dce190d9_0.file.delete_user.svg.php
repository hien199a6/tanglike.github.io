<?php
/* Smarty version 3.1.36, created on 2020-10-13 19:28:08
  from '/home/duyplusn/public_html/content/themes/default/images/svg/delete_user.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5f85ffc8311642_72504978',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9e95e72e19fc0dd1c4bfa200b85549b9dce190d9' => 
    array (
      0 => '/home/duyplusn/public_html/content/themes/default/images/svg/delete_user.svg',
      1 => 1602333724,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f85ffc8311642_72504978 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 417.118 417.118" style="enable-background:new 0 0 417.118 417.118;" xml:space="preserve">
<g>
	<g>
		<g>
			<g id="XMLID_16_">
				<g>
					<path style="fill:#FCD09F;" d="M176.505,0c46.66,0,84.49,37.82,84.49,84.48c0,46.67-37.83,110.49-84.49,110.49
						s-84.49-63.82-84.49-110.49C92.015,37.82,129.845,0,176.505,0z"/>
				</g>
			</g>
		</g>
		<circle style="fill:#EF806F;" cx="303.365" cy="327.118" r="90"/>
		<g>
			
				<rect x="241.141" y="319.614" transform="matrix(-0.7071 -0.7071 0.7071 -0.7071 286.5729 772.9305)" style="fill:#FFFFFF;" width="124.45" height="15"/>
		</g>
		<g>
			
				<rect x="241.144" y="319.619" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -142.453 310.3252)" style="fill:#FFFFFF;" width="124.45" height="15"/>
		</g>
	</g>
	<path style="fill:#1EA6C6;" d="M199.363,327.118c0,21.69,6.67,41.85,18.09,58.54c-13.28,2.42-26.97,3.68-40.95,3.68
		c-58.79,0-112.38-22.3-152.75-58.91v-0.13c0-60.89,35.63-113.45,87.17-137.98c19.37,19.32,42.05,29.73,65.58,29.73
		c23.54,0,46.21-10.41,65.59-29.73c16.76,7.98,31.84,18.92,44.54,32.15C237.213,232.488,199.363,275.468,199.363,327.118z"/>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
