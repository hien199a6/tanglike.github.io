<?php
/* Smarty version 3.1.36, created on 2020-10-12 20:17:24
  from '/home/duyplusn/public_html/content/themes/default/images/svg/products.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5f84b9d471a9d4_79254934',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '33eb018067eda7b071dec8273de5436bf461c681' => 
    array (
      0 => '/home/duyplusn/public_html/content/themes/default/images/svg/products.svg',
      1 => 1602333724,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f84b9d471a9d4_79254934 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
<linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="236.9345" y1="438.4175" x2="236.9345" y2="35.3575" gradientTransform="matrix(1.0667 0 0 -1.0667 3.2667 557.5334)">
	<stop  offset="0" style="stop-color:#1ACEB8"/>
	<stop  offset="1" style="stop-color:#0BBFBA"/>
</linearGradient>
<path style="fill:url(#SVGID_1_);" d="M457.118,512H54.876c-16.796,0-30.412-13.616-30.412-30.412V70.028
	c0-16.796,13.616-30.412,30.412-30.412h402.242c16.796,0,30.412,13.616,30.412,30.412v411.561
	C487.53,498.384,473.914,512,457.118,512z"/>
<linearGradient id="SVGID_2_" gradientUnits="userSpaceOnUse" x1="364.4096" y1="331.9996" x2="82.3496" y2="614.0596" gradientTransform="matrix(1.0667 0 0 -1.0667 3.2667 557.5334)">
	<stop  offset="1.000000e-004" style="stop-color:#1ACEB8;stop-opacity:0"/>
	<stop  offset="1" style="stop-color:#04959C"/>
</linearGradient>
<path style="fill:url(#SVGID_2_);" d="M487.53,70.028c0-16.796-13.616-30.412-30.412-30.412H54.876
	c-0.095,0-0.189,0.006-0.284,0.007v67.927l404.387,404.386c15.929-0.962,28.551-14.179,28.551-30.35V70.028H487.53z"/>
<path style="fill:#07ADB5;" d="M457.118,39.616H54.876c-16.796,0-30.412,13.616-30.412,30.412v7.106
	c0,16.796,13.616,30.412,30.412,30.412h402.242c16.796,0,30.412-13.616,30.412-30.412v-7.106
	C487.53,53.232,473.914,39.616,457.118,39.616z"/>
<linearGradient id="SVGID_3_" gradientUnits="userSpaceOnUse" x1="111.056" y1="472.9285" x2="111.056" y2="430.8275" gradientTransform="matrix(1.0667 0 0 -1.0667 3.2667 557.5334)">
	<stop  offset="0" style="stop-color:#FFCF95"/>
	<stop  offset="0.427" style="stop-color:#FFC954"/>
	<stop  offset="1" style="stop-color:#FFC200"/>
</linearGradient>
<path style="fill:url(#SVGID_3_);" d="M188.861,11.69v95.861H54.592V11.69c0-6.449,5.239-11.687,11.689-11.687h110.893
	C183.621,0.001,188.861,5.241,188.861,11.69z"/>
<linearGradient id="SVGID_4_" gradientUnits="userSpaceOnUse" x1="111.056" y1="533.7375" x2="111.056" y2="482.2305" gradientTransform="matrix(1.0667 0 0 -1.0667 3.2667 557.5334)">
	<stop  offset="0" style="stop-color:#FFCF95"/>
	<stop  offset="0.427" style="stop-color:#FFC954"/>
	<stop  offset="1" style="stop-color:#FFC200"/>
</linearGradient>
<path style="fill:url(#SVGID_4_);" d="M177.169,0H66.284c-6.458,0-11.693,5.235-11.693,11.693v31.379
	c0,6.458,5.235,11.693,11.693,11.693h110.885c6.458,0,11.693-5.235,11.693-11.693V11.693C188.862,5.235,183.627,0,177.169,0z"/>
<linearGradient id="SVGID_5_" gradientUnits="userSpaceOnUse" x1="362.813" y1="472.9285" x2="362.813" y2="430.8275" gradientTransform="matrix(1.0667 0 0 -1.0667 3.2667 557.5334)">
	<stop  offset="0" style="stop-color:#C2D600"/>
	<stop  offset="1" style="stop-color:#7BD101"/>
</linearGradient>
<path style="fill:url(#SVGID_5_);" d="M457.402,11.69v95.861H323.133V11.69c0-6.449,5.239-11.687,11.689-11.687h110.893
	C452.162,0.001,457.402,5.241,457.402,11.69z"/>
<linearGradient id="SVGID_6_" gradientUnits="userSpaceOnUse" x1="362.813" y1="533.7375" x2="362.813" y2="482.2305" gradientTransform="matrix(1.0667 0 0 -1.0667 3.2667 557.5334)">
	<stop  offset="0" style="stop-color:#C2D600"/>
	<stop  offset="1" style="stop-color:#7BD101"/>
</linearGradient>
<path style="fill:url(#SVGID_6_);" d="M445.71,0H334.825c-6.458,0-11.693,5.235-11.693,11.693v31.379
	c0,6.458,5.235,11.693,11.693,11.693H445.71c6.458,0,11.693-5.235,11.693-11.693V11.693C457.403,5.235,452.168,0,445.71,0z"/>
<linearGradient id="SVGID_7_" gradientUnits="userSpaceOnUse" x1="236.934" y1="460.7745" x2="236.934" y2="428.6975" gradientTransform="matrix(1.0667 0 0 -1.0667 3.2667 557.5334)">
	<stop  offset="0" style="stop-color:#B761C6"/>
	<stop  offset="1" style="stop-color:#9C44B3"/>
</linearGradient>
<path style="fill:url(#SVGID_7_);" d="M323.131,37.285v70.266H188.862V37.285c0-6.449,5.239-11.687,11.689-11.687h110.893
	C317.892,25.598,323.131,30.836,323.131,37.285z"/>
<linearGradient id="SVGID_8_" gradientUnits="userSpaceOnUse" x1="236.934" y1="509.7425" x2="236.934" y2="458.2375" gradientTransform="matrix(1.0667 0 0 -1.0667 3.2667 557.5334)">
	<stop  offset="0" style="stop-color:#B761C6"/>
	<stop  offset="1" style="stop-color:#9C44B3"/>
</linearGradient>
<path style="fill:url(#SVGID_8_);" d="M311.44,25.597H200.554c-6.458,0-11.693,5.235-11.693,11.693v31.38
	c0,6.458,5.235,11.693,11.693,11.693h110.885c6.458,0,11.693-5.235,11.693-11.693V37.289
	C323.132,30.831,317.898,25.597,311.44,25.597z"/>
<linearGradient id="SVGID_9_" gradientUnits="userSpaceOnUse" x1="189.2075" y1="269.8175" x2="55.9475" y2="403.0775" gradientTransform="matrix(1.0667 0 0 -1.0667 3.2667 557.5334)">
	<stop  offset="1.000000e-004" style="stop-color:#1ACEB8;stop-opacity:0"/>
	<stop  offset="1" style="stop-color:#04959C"/>
</linearGradient>
<circle style="fill:url(#SVGID_9_);" cx="114.517" cy="179.157" r="23.801"/>
<linearGradient id="SVGID_10_" gradientUnits="userSpaceOnUse" x1="454.4825" y1="269.8125" x2="321.2225" y2="403.0725" gradientTransform="matrix(1.0667 0 0 -1.0667 3.2667 557.5334)">
	<stop  offset="1.000000e-004" style="stop-color:#1ACEB8;stop-opacity:0"/>
	<stop  offset="1" style="stop-color:#04959C"/>
</linearGradient>
<circle style="fill:url(#SVGID_10_);" cx="397.472" cy="179.157" r="23.801"/>
<linearGradient id="SVGID_11_" gradientUnits="userSpaceOnUse" x1="307.198" y1="231.698" x2="136.878" y2="402.018" gradientTransform="matrix(1.0667 0 0 -1.0667 3.2667 557.5334)">
	<stop  offset="1.000000e-004" style="stop-color:#1ACEB8;stop-opacity:0"/>
	<stop  offset="1" style="stop-color:#04959C"/>
</linearGradient>
<path style="fill:url(#SVGID_11_);" d="M487.536,248.342v233.246c0,16.793-13.619,30.412-30.412,30.412H313.475L147.188,345.714
	c-30.505-29.287-49.518-70.635-49.518-116.199v-48.037c0-9.137,7.391-16.528,16.528-16.528c5.792,0,10.895,2.988,13.844,7.51
	c0,0,174.854,174.577,175.278,174.921c45.684-18.71,77.947-63.653,77.947-116.001v-49.902c0-9.137,7.405-16.528,16.528-16.528
	c5.805,0,10.895,2.988,13.844,7.51L487.536,248.342z"/>
<linearGradient id="SVGID_12_" gradientUnits="userSpaceOnUse" x1="236.934" y1="375.8075" x2="236.934" y2="80.7375" gradientTransform="matrix(1.0667 0 0 -1.0667 3.2667 557.5334)">
	<stop  offset="0" style="stop-color:#FFFFFF"/>
	<stop  offset="1" style="stop-color:#E8EFEE"/>
</linearGradient>
<path style="fill:url(#SVGID_12_);" d="M258.837,389.691c-88.839,1.571-161.173-71.322-161.173-160.174v-48.045
	c0-9.129,7.399-16.528,16.528-16.528l0,0c9.129,0,16.528,7.399,16.528,16.528v48.186c0,70.343,57.196,128.228,127.527,126.982
	c68.043-1.205,123.025-56.932,123.025-125.257v-49.911c0-9.129,7.399-16.528,16.528-16.528l0,0c9.129,0,16.528,7.399,16.528,16.528
	v49.911C414.33,317.739,344.836,388.171,258.837,389.691z"/>
<linearGradient id="SVGID_13_" gradientUnits="userSpaceOnUse" x1="447.9675" y1="90.7175" x2="258.3075" y2="280.3775" gradientTransform="matrix(1.0667 0 0 -1.0667 3.2667 557.5334)">
	<stop  offset="1.000000e-004" style="stop-color:#1ACEB8;stop-opacity:0"/>
	<stop  offset="1" style="stop-color:#04959C"/>
</linearGradient>
<path style="fill:url(#SVGID_13_);" d="M487.53,481.588V248.341l-75.851-75.838c1.679,2.592,2.644,5.66,2.644,8.965v49.915
	c0,86.356-69.485,156.793-155.484,158.314c-43.171,0.754-82.443-16.065-111.413-43.754L313.473,512h143.645
	C473.914,512,487.53,498.384,487.53,481.588z"/>
<linearGradient id="SVGID_14_" gradientUnits="userSpaceOnUse" x1="236.9345" y1="127.8975" x2="236.9345" y2="30.9175" gradientTransform="matrix(1.0667 0 0 -1.0667 3.2667 557.5334)">
	<stop  offset="1.000000e-004" style="stop-color:#1ACEB8;stop-opacity:0"/>
	<stop  offset="0.769" style="stop-color:#04959C"/>
</linearGradient>
<path style="fill:url(#SVGID_14_);" d="M24.464,397.315v82.95c0,16.796,13.616,30.412,30.412,30.412h402.242
	c16.796,0,30.412-13.616,30.412-30.412v-82.95H24.464z"/>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
