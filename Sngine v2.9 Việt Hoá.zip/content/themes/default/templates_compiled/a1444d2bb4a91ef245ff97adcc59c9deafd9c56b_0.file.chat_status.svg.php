<?php
/* Smarty version 3.1.36, created on 2020-10-13 19:41:48
  from '/home/duyplusn/public_html/content/themes/default/images/svg/chat_status.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5f8602fcbcd336_57581903',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a1444d2bb4a91ef245ff97adcc59c9deafd9c56b' => 
    array (
      0 => '/home/duyplusn/public_html/content/themes/default/images/svg/chat_status.svg',
      1 => 1602333724,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f8602fcbcd336_57581903 (Smarty_Internal_Template $_smarty_tpl) {
?><svg id="Layer_2" enable-background="new 0 0 64 64" height="512" viewBox="0 0 64 64" width="512" xmlns="http://www.w3.org/2000/svg"><circle cx="26" cy="29" fill="#6e83b7" r="24"/><circle cx="26" cy="29" fill="#edeff1" r="20"/><circle cx="26" cy="20.429" fill="#6e83b7" r="9"/><path d="m31.143 32.429h-10.286c-5.636 0-10.208 4.535-10.279 10.154 3.77 4.277 9.273 6.989 15.422 6.989s11.652-2.712 15.422-6.989c-.071-5.62-4.643-10.154-10.279-10.154z" fill="#6e83b7"/><circle cx="48" cy="45" fill="#ffb0aa" r="14"/><path d="m48.917 53.401-5.058-12.139-3.279 5.738h-4.58v-2h3.42l4.721-8.262 4.942 11.861 3.793-7.587 2.659 3.988h4.465v2h-5.535l-1.341-2.012z" fill="#ff7b7b"/></svg><?php }
}
