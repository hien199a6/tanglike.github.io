<?php
/* Smarty version 3.1.36, created on 2020-10-13 19:41:48
  from '/home/duyplusn/public_html/content/themes/default/images/svg/chat_seen.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5f8602fcbd7d64_66118331',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3cd97086cf66c2410204d866cb3403011dd3e686' => 
    array (
      0 => '/home/duyplusn/public_html/content/themes/default/images/svg/chat_seen.svg',
      1 => 1602333724,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f8602fcbd7d64_66118331 (Smarty_Internal_Template $_smarty_tpl) {
?><svg id="Capa_1" enable-background="new 0 0 512 512" height="512" viewBox="0 0 512 512" width="512" xmlns="http://www.w3.org/2000/svg"><g><path d="m512 154.352-49.532-49.532-49.532 49.531-203.292 104.237-61.05-61.05-49.532 49.532 51.046 61.047 59.535 49.534 49.529 49.529z" fill="#2681ff"/><path d="m412.938 154.352-49.532-49.532-203.296 203.295-110.577-110.577-49.533 49.532 160.11 160.11z" fill="#69b1e9"/></g></svg><?php }
}
