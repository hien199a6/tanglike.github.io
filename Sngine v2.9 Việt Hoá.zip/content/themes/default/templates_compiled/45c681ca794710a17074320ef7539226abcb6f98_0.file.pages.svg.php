<?php
/* Smarty version 3.1.36, created on 2020-10-12 20:17:24
  from '/home/duyplusn/public_html/content/themes/default/images/svg/pages.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5f84b9d47225b0_89292217',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '45c681ca794710a17074320ef7539226abcb6f98' => 
    array (
      0 => '/home/duyplusn/public_html/content/themes/default/images/svg/pages.svg',
      1 => 1602333724,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f84b9d47225b0_89292217 (Smarty_Internal_Template $_smarty_tpl) {
?><svg id="Capa_1" enable-background="new 0 0 512 512" height="512" viewBox="0 0 512 512" width="512" xmlns="http://www.w3.org/2000/svg"><g><path d="m512 165v-15h-211v302h211v-15c0-37.162-8.647-56.762-16.276-74.055-7.365-16.691-13.724-31.107-13.724-61.945s6.359-45.254 13.724-61.945c7.629-17.293 16.276-36.893 16.276-74.055z" fill="#3b88f5"/><path d="m286 60h-226v302h196l90 45v-287c0-33.084-26.916-60-60-60z" fill="#28abfa"/><path d="m301 362h-45v45c0 24.75 20.25 45 45 45s45-20.25 45-45-20.25-45-45-45z" fill="#3a6fd8"/><path d="m0 0h45v512h-45z" fill="#ff7b2d"/><path d="m45 0h45v512h-45z" fill="#ff5d34"/></g></svg><?php }
}
