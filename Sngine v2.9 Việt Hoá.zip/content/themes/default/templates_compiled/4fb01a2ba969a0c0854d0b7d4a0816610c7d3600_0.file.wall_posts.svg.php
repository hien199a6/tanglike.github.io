<?php
/* Smarty version 3.1.36, created on 2020-10-13 19:16:51
  from '/home/duyplusn/public_html/content/themes/default/images/svg/wall_posts.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5f85fd23d0b011_24618941',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4fb01a2ba969a0c0854d0b7d4a0816610c7d3600' => 
    array (
      0 => '/home/duyplusn/public_html/content/themes/default/images/svg/wall_posts.svg',
      1 => 1602333724,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f85fd23d0b011_24618941 (Smarty_Internal_Template $_smarty_tpl) {
?><svg height="512" viewBox="0 0 44 58" width="512" xmlns="http://www.w3.org/2000/svg"><g id="Page-1" fill="none" fill-rule="evenodd"><g id="028---Flag" fill-rule="nonzero"><path id="Shape" d="m22 16h-18v39.9482c-.01475597.7159904.35424806 1.3852793.96758525 1.7549784.6133372.3696991 1.37748569.3834365 2.00371475.0360216l14.0574-9.43c.2958629-.1689251.6306089-.2579104.9713-.2582v.009c.3395959-.0026307.6739813.0835511.97.25l13.3639 8.9631.6948.4661.0009.0006c.6259075.3475105 1.3898244.3339672 2.0030206-.0355111.6131961-.3694784.9821377-1.0385334.9673794-1.7542889v-39.95z" fill="#65ddb9"/><path id="Shape" d="m22 16h-12v32.36l7.9248-5.3165.1924-.109c2.4063789-1.3733359 5.3592211-1.3733359 7.7656 0l.1924.109 7.9248 5.3165v-32.36z" fill="#894b9d"/><path id="Shape" d="m34 11.9984c-.2393649.0001654-.4708359-.0856027-.6523-.2417l-11.3594-9.768-11.336 9.768c-.4188251.3602553-1.05039464.3127751-1.41064997-.10605-.36025533-.4188252-.31277514-1.0503947.10604997-1.41065l11.3593-9.7679c.7423809-.62546597 1.8260804-.62967729 2.5733-.01l11.372 9.7779c.3172607.2726623.4312744.7139906.2857786 1.1062024-.1454957.3922118-.5197497.6524113-.9380786.6521976z" fill="#2c3e50"/><path id="Shape" d="m40.5 10h-37c-1.9329966 0-3.49999993 1.5670034-3.49999993 3.5s1.56700333 3.5 3.49999993 3.5h37c1.9329966 0 3.4999999-1.5670034 3.4999999-3.5s-1.5670033-3.5-3.4999999-3.5z" fill="#f0c419"/></g></g></svg><?php }
}
