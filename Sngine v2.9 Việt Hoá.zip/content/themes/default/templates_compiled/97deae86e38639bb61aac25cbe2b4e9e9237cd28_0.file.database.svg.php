<?php
/* Smarty version 3.1.36, created on 2020-10-13 20:02:35
  from '/home/duyplusn/public_html/content/themes/default/images/svg/database.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5f8607dbbfaa12_06578103',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '97deae86e38639bb61aac25cbe2b4e9e9237cd28' => 
    array (
      0 => '/home/duyplusn/public_html/content/themes/default/images/svg/database.svg',
      1 => 1602333724,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f8607dbbfaa12_06578103 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 58 58" style="enable-background:new 0 0 58 58;" xml:space="preserve">
<path style="fill:#424A60;" d="M34,0C22.773,0,13.35,2.73,10.728,6.418C4.63,7.854,0.495,10.252,0.045,13l0,0H0v0.5V25v0.5V26v11
	v0.5V38v12h0.045C0.776,54.461,11.219,58,24,58c11.227,0,20.648-2.731,23.269-6.419c6.097-1.436,10.236-3.833,10.687-6.581H58V33
	v-0.5V21v-0.5v-12C58,3.806,47.255,0,34,0z"/>
<g>
	<path style="fill:#424A60;" d="M24,46c-13.255,0-24-3.806-24-8.5V50h0.045C0.776,54.461,11.219,58,24,58s23.224-3.539,23.955-8H48
		V37.5C48,42.194,37.255,46,24,46z"/>
	<path style="fill:#424A60;" d="M0,37v0.5c0-0.168,0.018-0.334,0.045-0.5H0z"/>
	<path style="fill:#424A60;" d="M47.955,37C47.982,37.166,48,37.332,48,37.5V37H47.955z"/>
</g>
<g>
	<path style="fill:#556080;" d="M24,34c-13.255,0-24-3.806-24-8.5V38h0.045C0.776,42.461,11.219,46,24,46s23.224-3.539,23.955-8H48
		V25.5C48,30.194,37.255,34,24,34z"/>
	<path style="fill:#556080;" d="M0,25v0.5c0-0.168,0.018-0.334,0.045-0.5H0z"/>
	<path style="fill:#556080;" d="M47.955,25C47.982,25.166,48,25.332,48,25.5V25H47.955z"/>
</g>
<ellipse style="fill:#7FABDA;" cx="24" cy="13.5" rx="24" ry="8.5"/>
<g>
	<path style="fill:#7383BF;" d="M24,22c-13.255,0-24-3.806-24-8.5V26h0.045C0.776,30.461,11.219,34,24,34s23.224-3.539,23.955-8H48
		V13.5C48,18.194,37.255,22,24,22z"/>
	<path style="fill:#7383BF;" d="M0,13v0.5c0-0.168,0.018-0.334,0.045-0.5H0z"/>
	<path style="fill:#7383BF;" d="M47.955,13C47.982,13.166,48,13.332,48,13.5V13H47.955z"/>
</g>
<path style="fill:#88C057;" d="M34,0C22.772,0,13.347,2.731,10.727,6.42C14.529,5.524,19.09,5,24,5c12.781,0,23.224,3.538,23.955,8
	H48v0.5v1.902c6.054-1.543,10-4.059,10-6.902C58,3.806,47.255,0,34,0z"/>
<path style="fill:#61B872;" d="M48,15.402V25v0.5V26v1.403c5.696-1.452,9.523-3.766,9.955-6.403H58V8.5
	C58,11.343,54.054,13.859,48,15.402z"/>
<path style="fill:#25AE88;" d="M48,27.402V37v0.5V38v1.403c5.696-1.452,9.523-3.766,9.955-6.403H58V20.5
	C58,23.343,54.054,25.859,48,27.402z"/>
<path style="fill:#1A9172;" d="M48,39.402V50h-0.045c-0.089,0.542-0.324,1.071-0.687,1.581c6.097-1.436,10.236-3.833,10.687-6.581
	H58V32.5C58,35.343,54.054,37.859,48,39.402z"/>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
