<?php
/* Smarty version 3.1.36, created on 2020-10-12 20:52:24
  from '/home/duyplusn/public_html/content/themes/default/images/svg/directory.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5f84c208189cb2_63330115',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f825dc7fcda35f5d264f4d0f0990d251f23d08c8' => 
    array (
      0 => '/home/duyplusn/public_html/content/themes/default/images/svg/directory.svg',
      1 => 1602333724,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f84c208189cb2_63330115 (Smarty_Internal_Template $_smarty_tpl) {
?><svg height="512" viewBox="0 0 64 64" width="512" xmlns="http://www.w3.org/2000/svg"><g id="File_system" data-name="File system"><path d="m61 32h-58l7.59-27.53a2 2 0 0 1 1.93-1.47h38.96a2 2 0 0 1 1.93 1.47z" fill="#004fac"/><path d="m61 32v25a4 4 0 0 1 -4 4h-50a4 4 0 0 1 -4-4v-25z" fill="#2488ff"/><path d="m56 32v22a4 4 0 0 1 -4 4h-48.859a3.989 3.989 0 0 0 3.859 3h50a4 4 0 0 0 4-4v-25z" fill="#006df0"/><path d="m8.253 28h47.494l-1.931-7h-43.632z" fill="#5eac24"/><path d="m49.954 7h-35.908l-1.931 7h39.77z" fill="#d80027"/><path d="m12.115 14-1.931 7h43.632l-1.931-7z" fill="#ffcd00"/><path d="m24.544 42.632a2 2 0 0 0 1.898 1.368h11.116a2 2 0 0 0 1.9-1.368l1.1-3.316a1 1 0 0 0 -.945-1.316h-15.226a1 1 0 0 0 -.948 1.316z" fill="#003f8a"/></g></svg><?php }
}
