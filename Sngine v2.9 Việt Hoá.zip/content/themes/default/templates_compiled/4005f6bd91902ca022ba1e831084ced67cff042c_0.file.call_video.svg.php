<?php
/* Smarty version 3.1.36, created on 2020-10-13 19:41:48
  from '/home/duyplusn/public_html/content/themes/default/images/svg/call_video.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5f8602fcbe6127_66167501',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4005f6bd91902ca022ba1e831084ced67cff042c' => 
    array (
      0 => '/home/duyplusn/public_html/content/themes/default/images/svg/call_video.svg',
      1 => 1602333724,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f8602fcbe6127_66167501 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
<path style="fill:#F44336;" d="M505.856,86.332c-3.744-1.758-8.168-1.193-11.349,1.451L382.08,181.478
	c-10.296-55.662-58.807-96.076-115.413-96.149H117.333C52.561,85.399,0.071,137.89,0,202.662v106.667
	c0.071,64.772,52.561,117.263,117.333,117.333h149.333c56.606-0.073,105.118-40.487,115.413-96.149l112.427,93.696
	c4.527,3.77,11.252,3.157,15.023-1.369c1.6-1.921,2.475-4.344,2.471-6.844v-320C512.001,91.855,509.606,88.087,505.856,86.332z"/>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
