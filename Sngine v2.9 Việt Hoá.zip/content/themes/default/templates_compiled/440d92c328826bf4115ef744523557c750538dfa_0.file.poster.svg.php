<?php
/* Smarty version 3.1.36, created on 2020-10-13 13:04:05
  from '/home/duyplusn/public_html/content/themes/default/images/svg/poster.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5f85a5c57d9560_17711203',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '440d92c328826bf4115ef744523557c750538dfa' => 
    array (
      0 => '/home/duyplusn/public_html/content/themes/default/images/svg/poster.svg',
      1 => 1602333724,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f85a5c57d9560_17711203 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 464 464" style="enable-background:new 0 0 464 464;" xml:space="preserve">
<path style="fill:#F88756;" d="M376,88v304c0,0-14.08,24-32,24L88,464V88H376z"/>
<path style="fill:#2E5166;" d="M344,416c-16,0-32-24-32-24L88,464L344,416z"/>
<g>
	<polygon style="fill:#E3DCD9;" points="0,128 128,0 128,24 152,24 152,48 176,48 48,176 48,152 24,152 24,128 	"/>
	<polygon style="fill:#E3DCD9;" points="464,128 336,0 336,24 312,24 312,48 288,48 416,176 416,152 440,152 440,128 	"/>
</g>
<polygon style="fill:#E0A700;" points="296,184 296,160 168,160 168,304 192,304 192,184 "/>
<rect x="192" y="184" style="fill:#FFBE00;" width="104" height="120"/>
<g>
	<rect x="160" y="112" style="fill:#E3DCD9;" width="16" height="24"/>
	<rect x="192" y="112" style="fill:#E3DCD9;" width="16" height="24"/>
	<rect x="224" y="112" style="fill:#E3DCD9;" width="16" height="24"/>
	<rect x="256" y="112" style="fill:#E3DCD9;" width="16" height="24"/>
	<rect x="288" y="112" style="fill:#E3DCD9;" width="16" height="24"/>
	<rect x="160" y="328" style="fill:#E3DCD9;" width="144" height="16"/>
	<rect x="160" y="360" style="fill:#E3DCD9;" width="40" height="16"/>
	<rect x="216" y="360" style="fill:#E3DCD9;" width="88" height="16"/>
	<rect x="160" y="392" style="fill:#E3DCD9;" width="56" height="16"/>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
